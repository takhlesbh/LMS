### v1.3 ###

* Fixed critical error thrown in Moodle 2.9 by switching to `\core\log\sql_reader`. Credit goes to Andrew Davis (@andyjdavis) for
  spotting and debugging this.
